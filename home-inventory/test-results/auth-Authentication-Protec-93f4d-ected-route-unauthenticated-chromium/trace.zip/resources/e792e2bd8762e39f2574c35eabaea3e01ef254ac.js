(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/eff95_cbd9fb62._.js",
  "static/chunks/home-inventory_src_0f6825f3._.js"
],
    source: "dynamic"
});
