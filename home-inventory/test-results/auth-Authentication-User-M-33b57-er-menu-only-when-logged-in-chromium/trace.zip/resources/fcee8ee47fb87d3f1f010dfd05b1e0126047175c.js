(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__983c891d._.css",
  "static/chunks/eff95_2ae045e5._.js",
  "static/chunks/home-inventory_src_59de3e09._.js"
],
    source: "dynamic"
});
