(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_4cf52588._.js",
  "static/chunks/eff95_next_dist_compiled_react-dom_d8b66977._.js",
  "static/chunks/eff95_next_dist_compiled_next-devtools_index_00690f12.js",
  "static/chunks/eff95_next_dist_compiled_e9843f7b._.js",
  "static/chunks/eff95_next_dist_client_f36bcafd._.js",
  "static/chunks/eff95_next_dist_3f054da4._.js",
  "static/chunks/eff95_@swc_helpers_cjs_f540a775._.js"
],
    source: "entry"
});
